INSERT INTO `publish` (`ID`, `PUBLISHINGHOUSE`, `CREATEDUSER`, `CREATEDDATE`, `UPLOADUSER`, `UPDATEDATE`) VALUES
(null, 'Kim Dong', 'Minh', '2019-07-28', 'Minh', '2019-07-28'),
(null, 'Ngoai Quoc', 'Quan', '2019-07-28', 'Quan', '2019-07-28'),
(null, 'Tuoi Tre', 'Duy', '2019-07-28', 'Duy', '2019-07-28'),
(null, 'Thanh Nien', 'Duy', '2019-07-28', 'Duy', '2019-07-28'),
(null, 'Giao Duc', 'Huy', '2019-07-28', 'Huy', '2019-07-28'),
(null, 'TPHCM', 'Huy', '2019-07-28', 'Huy', '2019-07-28'),
(null, 'Da Nang', 'Tai', '2019-07-28', 'Tai', '2019-07-28');