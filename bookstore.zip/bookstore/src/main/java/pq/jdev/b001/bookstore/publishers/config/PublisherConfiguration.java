package pq.jdev.b001.bookstore.publishers.config;

public class PublisherConfiguration {

}
